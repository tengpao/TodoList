<?php
/*
 * TestService接口实现类
 */
class TestService_Impl implements TestServiceIf {
	
	/*
	 * param 1: int
	 * return string
	 */
	public function getStr($type){
		switch($type){
			case 0:
				$return = 'hello world';break;
			case 1:
				$return = 'You are welcome!';break;
			case 2:
				$return = 'Read the fuck source code!';break;
		}
		return $return;
	}
}