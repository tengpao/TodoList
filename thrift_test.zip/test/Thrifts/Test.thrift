service TestService {
	# Thrift远程调用测试
    string getStr(1:i32 type);
}